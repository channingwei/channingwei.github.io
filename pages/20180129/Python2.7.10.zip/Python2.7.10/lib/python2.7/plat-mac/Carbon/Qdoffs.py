from _Qdoffs import *
